package com.example.rexus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RexusApplicationTests {

	@Test
	void contextLoads() {
	}

}
